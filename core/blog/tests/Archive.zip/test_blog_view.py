from django.test import TestCase, Client
from django.urls import reverse
from accounts.models import User, Profile
from blog.models import Post, Category

from datetime import datetime


class TestBlogViews(TestCase):

    def setUp(self):
        self.client = Client()

        self.user = User.objects.create_user(email="test@test.com", password="testpassword")

        self.profile = Profile.objects.create(
            user=self.user,
            first_name="Test",
            last_name="User",
            description="This is a test user.")

        self.post = Post.objects.create(
            author=self.profile,
            title='Test Post',
            content='This is a test post content.',
            published_date=datetime.now(),
            category=None,
            status=True)

    def test_blog_index_url_successfull_response(self):
        url = reverse('blog:index')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(str(response.content).find("Blog Index"))
        self.assertTemplateUsed(response, 'index.html')

    def test_blog_post_detail_is_logged_in_response(self):
        self.client.force_login(self.user)
        url = reverse('blog:post-detail', kwargs={'pk': self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_blog_post_detail_annonymos_response(self):
        url = reverse('blog:post-detail', kwargs={'pk': self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)

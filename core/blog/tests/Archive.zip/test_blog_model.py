from django.test import TestCase, SimpleTestCase
from django.contrib.auth import get_user_model

from datetime import datetime

from ..models import Post, Category
from accounts.models import User, Profile


class TestPostModel(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(email="test@test.com", password="testpassword")
        self.profile = Profile.objects.create(
            user=self.user,
            first_name="Test",
            last_name="User",
            description="This is a test user.")

    def test_create_post_with_valid_data(self):
        post = Post.objects.create(
            author=self.profile,
            title='Test Post',
            content='This is a test post content.',
            published_date=datetime.now(),
            category=None,
            status=True)
        self.assertTrue(Post.objects.filter(pk=post.id).exists())
        self.assertEqual(post.title, 'Test Post')


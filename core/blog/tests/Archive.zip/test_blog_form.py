from django.test import TestCase, SimpleTestCase
from ..forms import PostForm
from ..models import Category
from datetime import datetime


class TestPostForm(TestCase):

    def test_post_form_with_valid_data(self):
        category = Category.objects.create(name="Test")
        form = PostForm(data={
            'title': 'Test Post',
            'content': 'This is a test post content.',
            'published_date': datetime.now(),
            'category': category,
            'status': True})
        self.assertTrue(form.is_valid())

    def test_post_form_with_invalid_data(self):
        form = PostForm(data={
            'title': '',
            'content': 'This is a test post content without title.',
            'published_date': '',
            'category': '',
            'status': ''})
        self.assertFalse(form.is_valid())
